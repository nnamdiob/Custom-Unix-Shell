#include <stdio.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "builtin.h"
#include "job_control.h"
#include "parser.h"
#include "execution.h"
#include <errno.h>
#include <signal.h>





// Command loop
void lsh_loop(void) {
    char *line;
    char **args;
    int status;

    do {
        line = readline("> ");
        if (line && *line) {
            add_history(line);
        }
        
        args = parse_input(line);
        status = lsh_execute(args);

        free(line);
        free(args);
    } while (status);
}

// Main entry point
int main(int argc, char **argv) {
    signal(SIGINT, SIG_IGN);

    lsh_loop();
    return EXIT_SUCCESS;
}
