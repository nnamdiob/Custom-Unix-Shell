#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <signal.h>
#include "job_control.h"
#include <unistd.h>

// Job structure and list
Job job_list[MAX_JOBS];
int job_count = 0;



void add_job(pid_t pid, char **args) {
    if (job_count < MAX_JOBS) {
        job_list[job_count].pid = pid;
        snprintf(job_list[job_count].command, sizeof(job_list[job_count].command), "%s", args[0]);
        for (int i = 1; args[i] != NULL; i++) {
            strncat(job_list[job_count].command, " ", sizeof(job_list[job_count].command) - strlen(job_list[job_count].command) - 1);
            strncat(job_list[job_count].command, args[i], sizeof(job_list[job_count].command) - strlen(job_list[job_count].command) - 1);
        }
        job_count++;
    } else {
        printf("Job list is full. Cannot track more background jobs.\n");
    }
}



int lsh_jobs(char **args) {
    check_jobs(); // Update the job list by removing completed jobs

    if (job_count == 0) {
        printf("No background jobs.\n");
    } else {
        printf("Active background jobs:\n");
        for (int i = 0; i < job_count; i++) {
            printf("[%d] %d %s\n", i + 1, job_list[i].pid, job_list[i].command);
        }
    }
    return 1;
}




void check_jobs() {
    int status;
    for (int i = 0; i < job_count; i++) {
        pid_t result = waitpid(job_list[i].pid, &status, WNOHANG);
        if (result == -1) {
            perror("Error checking job status");
        } else if (result != 0) {
            // Process has finished; remove it from job list
            for (int j = i; j < job_count - 1; j++) {
                job_list[j] = job_list[j + 1];
            }
            job_count--;
            i--;  // Adjust index after removal
        }
    }
}




int lsh_fg(char **args) {
    int job_index;

    // Determine which job to bring to the foreground
    if (args[1] == NULL) {
        // If no job number specified, bring the most recent job to the foreground
        if (job_count == 0) {
            printf("fg: No jobs available\n");
            return 1;
        }
        job_index = job_count - 1;
    } else {
        // Parse the job number specified by the user
        job_index = atoi(args[1]) - 1;
        if (job_index < 0 || job_index >= job_count) {
            printf("fg: No such job\n");
            return 1;
        }
    }

    // Get the PID of the job
    pid_t pid = job_list[job_index].pid;

    // Bring the job to the foreground
    int status;
    if (waitpid(pid, &status, 0) == -1) {
        perror("fg: waitpid failed");
        return 1;
    }

    // Remove the job from the list
    for (int i = job_index; i < job_count - 1; i++) {
        job_list[i] = job_list[i + 1];
    }
    job_count--;

    return 1;
}






int lsh_bg(char **args) {
    int job_index;

    // Determine which job to resume in the background
    if (args[1] == NULL) {
        // If no job number specified, use the most recent job
        if (job_count == 0) {
            printf("bg: No jobs available\n");
            return 1;
        }
        job_index = job_count - 1;
    } else {
        // Parse the job number specified by the user
        job_index = atoi(args[1]) - 1;
        if (job_index < 0 || job_index >= job_count) {
            printf("bg: No such job\n");
            return 1;
        }
    }

    // Get the PID of the job
    pid_t pid = job_list[job_index].pid;

    // Send SIGCONT to resume the job in the background
    if (kill(pid, SIGCONT) == -1) {
        perror("bg: Failed to resume job");
        return 1;
    }

    printf("Job [%d] %d resumed in the background\n", job_index + 1, pid);

    return 1;
}