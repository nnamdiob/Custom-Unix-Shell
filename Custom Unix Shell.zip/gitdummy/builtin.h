#ifndef BUILTIN_H
#define BUILTIN_H

#define MAX_ALIASES 10

typedef struct {
    char *name;
    char *command;
} Alias;


extern Alias alias_list[MAX_ALIASES];
extern int alias_count;

int lsh_cd(char **args);
int lsh_help(char **args);
int lsh_exit(char **args);
int lsh_pwd(char **args);
int lsh_clear(char **args);
int lsh_alias(char **args);
int lsh_unalias(char **args);
// Declaration for built-in commands array
extern char *builtin_str[];
extern int (*builtin_func[]) (char **);
int lsh_num_builtins();

#endif
