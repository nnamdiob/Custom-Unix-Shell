#ifndef JOB_CONTROL_H
#define JOB_CONTROL_H

#include <sys/types.h>

#define MAX_JOBS 100

typedef struct {
    pid_t pid;
    char command[256];
} Job;

extern Job job_list[MAX_JOBS];
extern int job_count;

void add_job(pid_t pid, char **args);
int lsh_jobs(char **args);
void check_jobs();
int lsh_fg(char **args);
int lsh_bg(char **args);

#endif
