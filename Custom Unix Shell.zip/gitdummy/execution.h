#ifndef EXECUTION_H
#define EXECUTION_H

#include <unistd.h>

int lsh_execute(char **args);
int execute_piped_command(char **args, int pipe_position);
int lsh_launch(char **args); 

#endif
