#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "builtin.h"
#include "job_control.h"

// Alias structure
Alias alias_list[MAX_ALIASES];
int alias_count = 0;


// Built-in command list and function mappings
char *builtin_str[] = {
    "cd", "help", "exit", "alias", "pwd", "clear", "unalias", "jobs", "fg", "bg"
};

int (*builtin_func[]) (char **) = {
    &lsh_cd, &lsh_help, &lsh_exit, &lsh_alias, &lsh_pwd,
    &lsh_clear, &lsh_unalias, &lsh_jobs, &lsh_fg, &lsh_bg
};

int lsh_num_builtins() {
    return sizeof(builtin_str) / sizeof(char *);
}


// Built-in commands

int lsh_cd(char **args) {
    if (args[1] == NULL) {
        fprintf(stderr, "lsh: expected argument to \"cd\"\n");
    } else if (chdir(args[1]) != 0) {
        perror("lsh");
    }
    return 1;
}

int lsh_help(char **args) {
    printf("Shell Implementation\nType program names and arguments, and hit enter.\n");
    printf("The following are built in:\n");

    for (int i = 0; i < lsh_num_builtins(); i++) {
        printf("  %s\n", builtin_str[i]);
    }
    return 1;
}

int lsh_exit(char **args) {
    return 0;
}

int lsh_pwd(char **args) {
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("%s\n", cwd);
    } else {
        perror("lsh");
    }
    return 1;
}

int lsh_clear(char **args) {
    printf("\033[H\033[J");
    return 1;
}

// Alias Command Implementation
int lsh_alias(char **args) {
    if (args[1] == NULL) {
        for (int i = 0; i < alias_count; i++) {
            printf("alias %s='%s'\n", alias_list[i].name, alias_list[i].command);
        }
        return 1;
    }

    char *equal_sign = strchr(args[1], '=');
    if (equal_sign == NULL || equal_sign == args[1]) {
        fprintf(stderr, "lsh: alias usage: alias name='command'\n");
        return 1;
    }

    *equal_sign = '\0';
    char *name = args[1];
    char *command = equal_sign + 1;

    if ((command[0] == '\'' || command[0] == '"') && command[strlen(command) - 1] == command[0]) {
        command[strlen(command) - 1] = '\0';
        command++;
    }

    for (int i = 0; i < alias_count; i++) {
        if (strcmp(alias_list[i].name, name) == 0) {
            free(alias_list[i].command);
            alias_list[i].command = strdup(command);
            return 1;
        }
    }

    if (alias_count < MAX_ALIASES) {
        alias_list[alias_count].name = strdup(name);
        alias_list[alias_count].command = strdup(command);
        alias_count++;
    } else {
        fprintf(stderr, "lsh: alias limit reached\n");
    }
    return 1;
}

int lsh_unalias(char **args) {
    if (args[1] == NULL) {
        fprintf(stderr, "lsh: expected argument to \"unalias\"\n");
    } else {
        for (int i = 0; i < alias_count; i++) {
            if (strcmp(alias_list[i].name, args[1]) == 0) {
                free(alias_list[i].name);
                free(alias_list[i].command);
                alias_list[i] = alias_list[alias_count - 1];
                alias_count--;
                return 1;
            }
        }
        fprintf(stderr, "lsh: alias not found\n");
    }
    return 1;
}
