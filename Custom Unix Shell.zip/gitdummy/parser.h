#ifndef PARSER_H
#define PARSER_H

#define MAX_TOKENS 100
#define TOKEN_SIZE 1024

char **parse_input(char *input);

#endif
