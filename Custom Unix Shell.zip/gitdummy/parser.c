#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "parser.h"

char **parse_input(char *input) {
    char **tokens = malloc(MAX_TOKENS * sizeof(char *));
    int token_index = 0, in_quotes = 0;
    char quote_char = '\0', token[TOKEN_SIZE] = "";
    int token_length = 0, input_length = strlen(input);

    for (int i = 0; i < input_length; i++) {
        char c = input[i];
        if (c == '\\' && i + 1 < input_length) {
            token[token_length++] = input[++i];
        } else if ((c == '"' || c == '\'') && (in_quotes == 0 || c == quote_char)) {
            in_quotes = !in_quotes;
            quote_char = in_quotes ? c : '\0';
        } else if (isspace(c) && !in_quotes) {
            if (token_length > 0) {
                token[token_length] = '\0';
                tokens[token_index++] = strdup(token);
                token_length = 0;
            }
        } else {
            token[token_length++] = c;
        }
    }

    if (token_length > 0) {
        token[token_length] = '\0';
        tokens[token_index++] = strdup(token);
    }
    tokens[token_index] = NULL;
    return tokens;
}
