#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include "parser.h"
#include "job_control.h"
#include "execution.h"
#include "builtin.h"


// Implement lsh_launch
int lsh_launch(char **args) {
    pid_t pid;
    int status;

    pid = fork();
    if (pid == 0) {
        // Child process
        if (execvp(args[0], args) == -1) {
            perror("lsh");
        }
        exit(EXIT_FAILURE);
    } else if (pid < 0) {
        // Error forking
        perror("lsh");
    } else {
        // Parent process
        do {
            waitpid(pid, &status, WUNTRACED);
        } while (!WIFEXITED(status) && !WIFSIGNALED(status));
    }

    return 1;
}

int lsh_execute(char **args) {
    if (args[0] == NULL) {
        return 1; // Empty command
    }

    // Check if the command matches an alias
    for (int i = 0; i < alias_count; i++) {
        if (strcmp(args[0], alias_list[i].name) == 0) {
            char **expanded_args = parse_input(alias_list[i].command);
            int status = lsh_execute(expanded_args);  // Recursively execute the alias command
            free(expanded_args);
            return status;
        }
    }

    // Check for the presence of a pipe (|) in the command
    int pipe_position = -1;
    for (int i = 0; args[i] != NULL; i++) {
        if (strcmp(args[i], "|") == 0) {
            pipe_position = i;
            break;
        }
    }

    if (pipe_position != -1) {
        return execute_piped_command(args, pipe_position);
    }

    // Save original stdin and stdout file descriptors
    int saved_stdout = dup(STDOUT_FILENO);
    int saved_stdin = dup(STDIN_FILENO);
    int fd;

    // Handle output redirection (>)
    for (int i = 0; args[i] != NULL; i++) {
        if (strcmp(args[i], ">") == 0) {
            args[i] = NULL;  // Terminate args before the redirection symbol
            fd = open(args[i + 1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd == -1) {
                perror("lsh");
                return 1;
            }
            dup2(fd, STDOUT_FILENO); // Redirect stdout to the file
            close(fd);
            break;
        }
    }

    // Handle input redirection (<)
    for (int i = 0; args[i] != NULL; i++) {
        if (strcmp(args[i], "<") == 0) {
            args[i] = NULL;  // Terminate args before the redirection symbol
            fd = open(args[i + 1], O_RDONLY);
            if (fd == -1) {
                perror("lsh");
                return 1;
            }
            dup2(fd, STDIN_FILENO); // Redirect stdin to the file
            close(fd);
            break;
        }
    }

    // Check if the command should be run in the background
    int background = 0;
    for (int i = 0; args[i] != NULL; i++) {
        if (strcmp(args[i], "&") == 0) {
            background = 1;
            args[i] = NULL;  // Remove '&' from args
            break;
        }
    }

    // Check if command matches a built-in function
    for (int i = 0; i < lsh_num_builtins(); i++) {
        if (strcmp(args[0], builtin_str[i]) == 0) {
            int status = (*builtin_func[i])(args);

            // Restore stdin and stdout
            dup2(saved_stdout, STDOUT_FILENO);
            dup2(saved_stdin, STDIN_FILENO);
            close(saved_stdout);
            close(saved_stdin);

            return status;
        }
    }

    // Execute the command
    int status;
    pid_t pid = fork();
    if (pid == 0) {
        // Child process
        execvp(args[0], args); // Execute the command
        perror("lsh"); // Error handling if execvp fails
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        // Parent process
        if (!background) {
            waitpid(pid, &status, 0); // Wait for the child if it's a foreground job
        } else {
            printf("[Background] Process ID: %d\n", pid); // Print background job PID
            add_job(pid, args);  // Add the job to the job list
        }
    } else {
        perror("lsh: fork failed"); // Error if fork failed
    }

    // Restore original stdin and stdout after command execution
    dup2(saved_stdout, STDOUT_FILENO);
    dup2(saved_stdin, STDIN_FILENO);
    close(saved_stdout);
    close(saved_stdin);

    return 1;
}


int execute_piped_command(char **args, int pipe_position) {
    // Split the command at the pipe position
    args[pipe_position] = NULL; // Separate first and second command
    char **first_command = args;
    char **second_command = &args[pipe_position + 1];

    // Set up the pipe
    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("lsh: pipe");
        return 1;
    }

    // Fork the first child process
    pid_t pid1 = fork();
    if (pid1 == 0) {
        // First child process (first command)
        close(pipe_fd[0]); // Close read end of the pipe
        dup2(pipe_fd[1], STDOUT_FILENO); // Redirect stdout to pipe write end
        close(pipe_fd[1]); // Close original write end after duplicating

        execvp(first_command[0], first_command); // Execute the first command
        perror("lsh"); // If exec fails
        exit(EXIT_FAILURE);
    }

    // Fork the second child process
    pid_t pid2 = fork();
    if (pid2 == 0) {
        // Second child process (second command)
        close(pipe_fd[1]); // Close write end of the pipe
        dup2(pipe_fd[0], STDIN_FILENO); // Redirect stdin to pipe read end
        close(pipe_fd[0]); // Close original read end after duplicating

        execvp(second_command[0], second_command); // Execute the second command
        perror("lsh"); // If exec fails
        exit(EXIT_FAILURE);
    }

    // Parent process
    close(pipe_fd[0]); // Close both ends of the pipe in parent
    close(pipe_fd[1]);

    // Wait for both children to complete
    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);

    return 1;
}
